import GObject from "gi://GObject";
import St from "gi://St";
import Gio from "gi://Gio";
import Pango from "gi://Pango";
import GLib from "gi://GLib";
import Clutter from "gi://Clutter";
import * as PopupMenu from "resource:///org/gnome/shell/ui/popupMenu.js";
import * as DND from "resource:///org/gnome/shell/ui/dnd.js";
import { setupTooltip } from "../utils/tooltip.js";
// ─── Module-Level Phantom Hover Protection ───
// Wayland/Clutter picking causes "phantom hovers" when the scroll view shifts
// items underneath a stationary mouse pointer. These locks protect key focus.
let _intendedFocusActor = null;
let _phantomHoverLockId = 0;
// ─── Module-Level Actions View Tracker ───
// Ensures only one inline action menu can be open at a time globally.
let _activeActionsItem = null;
/**
 * ─── Phantom Hover Focus Lock ───
 * Globally suppresses pointer-driven focus stealing for a set duration.
 * Used during UI mapping, drawer animations, and layout shifts.
 */
export function acquirePhantomHoverLock(targetActor, ms = 100) {
    _intendedFocusActor = targetActor;
    if (_phantomHoverLockId !== 0) {
        GLib.source_remove(_phantomHoverLockId);
    }
    _phantomHoverLockId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
        _phantomHoverLockId = 0;
        _intendedFocusActor = null;
        return GLib.SOURCE_REMOVE;
    });
}
// ─── Registration ─────────────────────────────────────────────────────────────
export const TodoItem = GObject.registerClass({
    Signals: {
        "todo-toggle": { param_types: [GObject.TYPE_STRING] },
        "todo-delete": { param_types: [GObject.TYPE_STRING] },
        "todo-edit": { param_types: [GObject.TYPE_STRING, GObject.TYPE_STRING] },
        "todo-move": { param_types: [GObject.TYPE_STRING, GObject.TYPE_STRING] },
        "todo-move-step": { param_types: [GObject.TYPE_STRING, GObject.TYPE_INT, GObject.TYPE_BOOLEAN] },
        "todo-pin": { param_types: [GObject.TYPE_STRING] },
    },
}, class TodoItem extends PopupMenu.PopupBaseMenuItem {
    // ─── Private State ────────────────────────────────────────────────────────
    _text;
    _label;
    _entry;
    _isEditing = false;
    _actionsTimeoutId = null;
    _settings;
    _infoBtn;
    // Reliable state for DND boundary enforcement
    _isCompleted;
    _isPinned;
    _defaultView;
    _actionsView;
    // ─── Constructor ──────────────────────────────────────────────────────────
    constructor(text, completed, pinned, settings) {
        super({ activate: false });
        this._text = text;
        this._settings = settings;
        this._isCompleted = completed;
        this._isPinned = pinned;
        // ── Row container ──────────────────────────────────────────────────────
        const box = new St.BoxLayout({
            style_class: "todo-item-box",
            x_expand: true,
        });
        // ── Drag handle ────────────────────────────────────────────────────────
        const dragBtn = this._buildDragHandle();
        // ── Check button ───────────────────────────────────────────────────────
        const checkBtn = this._buildCheckButton(completed);
        // ── Label + inline edit entry ──────────────────────────────────────────
        this._label = new St.Label({
            text,
            style_class: completed ? "todo-label todo-label-done" : "todo-label",
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
            reactive: true, // Required for the actor to receive hover events for the tooltip
        });
        // ── STRICT ELLIPSIZATION ──
        // Delegate Wayland text truncation to the underlying Pango layout engine
        this._label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        // ── DYNAMIC TOOLTIP ──
        // We evaluate the Pango layout mathematically on hover. The tooltip will only
        // populate if the hardware renderer was forced to truncate this specific string.
        setupTooltip(this._label, () => {
            const layout = this._label.clutter_text.get_layout();
            if (layout.is_ellipsized()) {
                return this._text;
            }
            return ""; // Suppress the tooltip if the text fits completely
        });
        this._entry = new St.Entry({
            style_class: "todo-edit-entry",
            text: this._text,
            x_expand: true,
            visible: false,
            can_focus: true,
        });
        this._infoBtn = this._buildInfoButton();
        // ── Action buttons ─────────────────────────────────────────────────────
        const pinBtn = this._buildPinButton(pinned);
        const editBtn = this._buildEditButton();
        const deleteBtn = this._buildDeleteButton(pinned);
        // ── Layout ─────────────────────────────────────────────────────────────
        // ── Layout Orchestration (Inline Overflow Menu) ────────────────────────
        const rootBox = new St.BoxLayout({ style_class: "todo-item-box", x_expand: true });
        // 1. Globally Visible Elements
        rootBox.add_child(dragBtn);
        const dynamicContainer = new St.BoxLayout({ x_expand: true, y_align: Clutter.ActorAlign.CENTER });
        // 2. Default View (Text + Pinned + View More)
        this._defaultView = new St.BoxLayout({ x_expand: true });
        this._defaultView.add_child(this._label);
        if (pinned) {
            this._defaultView.add_child(pinBtn);
        }
        if (completed) {
            this._defaultView.add_child(checkBtn);
        }
        this._defaultView.add_child(this._infoBtn);
        const moreBtn = new St.Button({ style_class: "todo-edit-btn", x_align: Clutter.ActorAlign.END });
        moreBtn.add_child(new St.Icon({ icon_name: "view-more-symbolic", style_class: "todo-edit-icon" }));
        setupTooltip(moreBtn, "More actions");
        this._defaultView.add_child(moreBtn);
        // 3. Actions View (The Overflow Menu)
        // Added spacing so the buttons don't bunch together
        this._actionsView = new St.BoxLayout({ x_expand: true, visible: false, style: "spacing: 6px;" });
        this._actionsView.add_child(checkBtn);
        if (!pinned) {
            this._actionsView.add_child(pinBtn);
        }
        this._actionsView.add_child(editBtn);
        this._actionsView.add_child(deleteBtn);
        // Push the close button to the far right edge
        const spacer = new St.Widget({ x_expand: true });
        this._actionsView.add_child(spacer);
        const closeMoreBtn = new St.Button({ style_class: "todo-edit-btn", x_align: Clutter.ActorAlign.END });
        closeMoreBtn.add_child(new St.Icon({ icon_name: "go-previous-symbolic", style_class: "todo-edit-icon" }));
        setupTooltip(closeMoreBtn, "Back");
        this._actionsView.add_child(closeMoreBtn);
        // 4. Assemble Container
        dynamicContainer.add_child(this._defaultView);
        dynamicContainer.add_child(this._actionsView);
        dynamicContainer.add_child(this._entry);
        rootBox.add_child(dynamicContainer);
        this.add_child(rootBox);
        // ── Toggle Wiring ──
        moreBtn.connect("clicked", () => this.openActions());
        closeMoreBtn.connect("clicked", () => this.closeActions());
        // ── Hover-State Machine for Auto-Close ──
        // Pauses the close timer while the user is actively interacting with the row.
        this.connect("notify::hover", () => {
            // Only evaluate hover logic if this specific row's action menu is open
            if (_activeActionsItem !== this)
                return;
            if (this.hover) {
                // Pointer entered: Cancel the countdown
                this._clearActionsTimer();
            }
            else {
                // Pointer left: Start the 2-second countdown
                this._startActionsTimer();
            }
        });
        // CLEANUP: Prevent memory leaks and dangling pointers if the item is destroyed
        this.connect("destroy", () => {
            this._clearActionsTimer();
            if (_activeActionsItem === this) {
                _activeActionsItem = null;
            }
        });
        // ── STRICT VISIBILITY ENFORCEMENT ──
        // Clutter's St.BoxLayout mapping phase can sometimes override the `visible`
        // property passed in the constructor. We explicitly hide the actors here 
        // to guarantee they do not render for completed items.
        if (completed) {
            pinBtn.hide();
            editBtn.hide();
        }
        // Pinned items cannot be directly deleted until unpinned
        if (pinned) {
            deleteBtn.hide();
        }
        // ── Pango Evaluation Trigger ──
        // Calculate visibility once the row is physically rendered into the layout
        this._label.connect("notify::mapped", () => {
            if (this._label.is_mapped())
                this._updateInfoVisibility();
        });
        // ── Signal wiring ──────────────────────────────────────────────────────
        checkBtn.connect("clicked", () => this.emit("todo-toggle", this._text));
        deleteBtn.connect("clicked", () => this.emit("todo-delete", this._text));
        editBtn.connect("clicked", () => this._startEdit());
        pinBtn.connect("clicked", () => this.emit("todo-pin", this._text));
        // Commit edit when Enter is pressed or focus leaves the entry
        this._entry.clutter_text.connect("activate", () => this._finishEdit());
        this._entry.clutter_text.connect("key-focus-out", () => {
            if (this._isEditing)
                this._finishEdit();
        });
        // ── Keyboard shortcuts for the row ─────────────────────────────────────
        this._connectKeyboardEvents();
        // ── Scroll into view when focused ──────────────────────────────────────
        this.connect("notify::active", () => {
            if (this.active) {
                // Phantom Hover Protection: Reject activation if a scroll is shifting the layout
                if (_phantomHoverLockId !== 0 && _intendedFocusActor && _intendedFocusActor !== this) {
                    this.active = false;
                    return;
                }
                this._scrollToItem();
            }
            else {
                this.remove_style_class_name("todo-item-modifier-held");
            }
        });
        this.connect("key-focus-in", () => {
            // Phantom Hover Protection: Re-grab focus if a stationary pointer stole it
            if (_phantomHoverLockId !== 0 && _intendedFocusActor && _intendedFocusActor !== this) {
                GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                    if (_intendedFocusActor && _intendedFocusActor.is_mapped()) {
                        _intendedFocusActor.grab_key_focus();
                        // Only apply 'active' to actors that support it (TodoItem does, St.Entry does not)
                        if ("active" in _intendedFocusActor) {
                            _intendedFocusActor.active = true;
                        }
                    }
                    return GLib.SOURCE_REMOVE;
                });
                return;
            }
            this._scrollToItem();
        });
    }
    // ─── Button Builders ─────────────────────────────────────────────────────
    _buildDragHandle() {
        const btn = new St.Button({
            style_class: "todo-drag-btn",
            x_align: Clutter.ActorAlign.START,
            can_focus: false,
        });
        btn.add_child(new St.Icon({
            icon_name: "list-drag-handle-symbolic",
            style_class: "todo-drag-icon",
        }));
        // Wire GNOME DND; this row is both the draggable source and the drop target
        btn._delegate = this;
        this._delegate = this;
        DND.makeDraggable(btn, {});
        // Dynamic tooltip: shows current modifier key from settings
        setupTooltip(btn, () => {
            const mod = this._settings.get_string("drag-modifier");
            const modName = mod.charAt(0).toUpperCase() + mod.slice(1);
            return `Drag to reorder\n(${modName} + Up/Down)`;
        });
        return btn;
    }
    _buildCheckButton(completed) {
        const btn = new St.Button({
            style_class: completed ? "todo-check-btn todo-checked" : "todo-check-btn",
            x_align: Clutter.ActorAlign.START,
        });
        btn.add_child(new St.Icon({
            icon_name: completed ? "checkbox-checked-symbolic" : "checkbox-symbolic",
            style_class: "todo-check-icon",
        }));
        setupTooltip(btn, completed
            ? "Make it incomplete / press Space Key"
            : "Mark this Todo as completed / press Space Key");
        return btn;
    }
    _buildEditButton() {
        const btn = new St.Button({
            style_class: "todo-edit-btn",
            x_align: Clutter.ActorAlign.END,
        });
        btn.add_child(new St.Icon({
            icon_name: "document-edit-symbolic",
            style_class: "todo-edit-icon",
        }));
        setupTooltip(btn, "Edit this Todo");
        return btn;
    }
    _buildDeleteButton(pinned) {
        const btn = new St.Button({
            style_class: "todo-delete-btn",
            label: "×",
            x_align: Clutter.ActorAlign.END,
        });
        setupTooltip(btn, "Delete this Todo / Del key");
        return btn;
    }
    _buildPinButton(pinned) {
        const btn = new St.Button({
            style_class: pinned ? "todo-pin-btn todo-pinned" : "todo-pin-btn",
            x_align: Clutter.ActorAlign.END,
        });
        btn.add_child(new St.Icon({
            icon_name: pinned ? "starred-symbolic" : "non-starred-symbolic",
            style_class: "todo-pin-icon",
        }));
        setupTooltip(btn, "Pin this Todo to the top");
        return btn;
    }
    _buildInfoButton() {
        const btn = new St.Button({
            style_class: "todo-edit-btn",
            x_align: Clutter.ActorAlign.END,
            visible: false, // Hidden by default; evaluated after layout allocation
            can_focus: false, // Prevent it from interrupting Up/Down keyboard navigation
        });
        btn.add_child(new St.Icon({
            icon_name: "dialog-information-symbolic", // Standard Adwaita info icon
            style_class: "todo-edit-icon",
        }));
        // The tooltip dynamically fetches the latest text (useful if edited)
        setupTooltip(btn, () => this._text);
        return btn;
    }
    //private method to evaluate the Pango layout. By wrapping it in GLib.idle_add, 
    // we wait for the GPU to finish painting the geometry before we interrogate the ellipsis status.
    _updateInfoVisibility() {
        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            // Ensure the widget still exists and is painted on screen
            if (!this._label || !this._label.is_mapped())
                return GLib.SOURCE_REMOVE;
            const layout = this._label.clutter_text.get_layout();
            const isCut = layout.is_ellipsized();
            // Only trigger a scene graph mutation if the state actually needs to change
            if (this._infoBtn.visible !== isCut) {
                this._infoBtn.visible = isCut;
            }
            return GLib.SOURCE_REMOVE;
        });
    }
    // ─── Actions View State Management ───────────────────────────────────────
    openActions() {
        // 1. Exclusivity Check: Close any other open actions view globally
        if (_activeActionsItem && _activeActionsItem !== this) {
            if (typeof _activeActionsItem.closeActions === "function") {
                _activeActionsItem.closeActions();
            }
        }
        _activeActionsItem = this;
        // 2. Clear any existing timer for this specific instance
        this._clearActionsTimer();
        // 3. Toggle UI states
        this._defaultView.hide();
        this._actionsView.show();
        this.add_style_class_name("todo-item-actions-active");
        // 4. Start timer ONLY if the pointer is not currently hovering over this row
        if (!this.hover) {
            this._startActionsTimer();
        }
    }
    closeActions() {
        this._clearActionsTimer();
        if (_activeActionsItem === this) {
            _activeActionsItem = null;
        }
        this._actionsView.hide();
        this._defaultView.show();
        this.remove_style_class_name("todo-item-actions-active");
    }
    _startActionsTimer() {
        this._clearActionsTimer();
        this._actionsTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.closeActions();
            return GLib.SOURCE_REMOVE;
        });
    }
    _clearActionsTimer() {
        if (this._actionsTimeoutId) {
            GLib.source_remove(this._actionsTimeoutId);
            this._actionsTimeoutId = null;
        }
    }
    // ─── Inline Edit ─────────────────────────────────────────────────────────
    _startEdit() {
        if (this._isEditing)
            return;
        this._isEditing = true;
        // Ensure timers are cancelled and CSS highlights are removed
        this.closeActions();
        // Hide the default view to make room for the text entry
        this._defaultView.hide();
        this._entry.set_text(this._text);
        this._entry.show();
        // Defer focus grab so Clutter's layout pass completes first
        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            this._entry.grab_key_focus();
            return GLib.SOURCE_REMOVE;
        });
    }
    _finishEdit() {
        if (!this._isEditing)
            return;
        this._isEditing = false;
        const newText = this._entry.get_text().trim();
        this._entry.hide();
        this._defaultView.show(); // Always restore to the default view
        // CLEANUP: Redundantly strip the highlight just to guarantee a clean state
        this.remove_style_class_name("todo-item-actions-active");
        if (newText && newText !== this._text) {
            const oldText = this._text;
            this._text = newText;
            this._label.set_text(newText);
            this.emit("todo-edit", oldText, newText);
            this._updateInfoVisibility();
        }
        else if (!newText) {
            this._entry.set_text(this._text);
        }
    }
    // ─── Keyboard Events ─────────────────────────────────────────────────────
    /**
     * Connect keyboard handlers:
     *   Space       → toggle completed
     *   Delete      → delete todo
     *   Mod + Up/Down → reorder one step
     *   Mod key held → show yellow highlight
     */
    _connectKeyboardEvents() {
        this.connect("key-press-event", (_actor, event) => {
            const state = event.get_state();
            const keyval = event.get_key_symbol();
            // Space → toggle
            if (keyval === Clutter.KEY_space) {
                this.emit("todo-toggle", this._text);
                return Clutter.EVENT_STOP;
            }
            // Delete → remove
            if (keyval === Clutter.KEY_Delete) {
                this.emit("todo-delete", this._text);
                return Clutter.EVENT_STOP;
            }
            // Resolve configured modifier
            const { mask, isModKey } = this._resolveModifier(keyval);
            const hasMod = (state & mask) !== 0 || isModKey;
            // Visual feedback while modifier is held
            if (hasMod) {
                this.add_style_class_name("todo-item-modifier-held");
            }
            // Modifier + arrow → reorder
            if ((state & mask) !== 0) {
                if (keyval === Clutter.KEY_Up) {
                    this.emit("todo-move-step", this._text, -1, true);
                    return Clutter.EVENT_STOP;
                }
                if (keyval === Clutter.KEY_Down) {
                    this.emit("todo-move-step", this._text, 1, true);
                    return Clutter.EVENT_STOP;
                }
            }
            return Clutter.EVENT_PROPAGATE;
        });
        this.connect("key-release-event", (_actor, event) => {
            const keyval = event.get_key_symbol();
            const { isModKey } = this._resolveModifier(keyval);
            if (isModKey) {
                this.remove_style_class_name("todo-item-modifier-held");
            }
            return Clutter.EVENT_PROPAGATE;
        });
    }
    /**
     * Resolve the Clutter modifier mask and modifier-key detection based on
     * the "drag-modifier" GSettings value ("alt" | "ctrl" | "shift").
     */
    _resolveModifier(keyval) {
        const modStr = this._settings.get_string("drag-modifier");
        if (modStr === "ctrl") {
            return {
                mask: Clutter.ModifierType.CONTROL_MASK,
                isModKey: keyval === Clutter.KEY_Control_L || keyval === Clutter.KEY_Control_R,
            };
        }
        if (modStr === "shift") {
            return {
                mask: Clutter.ModifierType.SHIFT_MASK,
                isModKey: keyval === Clutter.KEY_Shift_L || keyval === Clutter.KEY_Shift_R,
            };
        }
        // Default: Alt
        return {
            mask: Clutter.ModifierType.MOD1_MASK,
            isModKey: keyval === Clutter.KEY_Alt_L || keyval === Clutter.KEY_Alt_R,
        };
    }
    // ─── Scroll Helper ────────────────────────────────────────────────────────
    /**
     * Ensure this row is visible inside its ancestor St.ScrollView.
     * Uses duck-typing to find the scroll view (avoids GJS instanceof quirks).
     */
    _scrollToItem() {
        GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            if (!this.is_mapped())
                return GLib.SOURCE_REMOVE;
            // Walk up the actor tree looking for a scroll view
            let parent = this.get_parent();
            let scrollView = null;
            while (parent) {
                if ("vscroll" in parent || typeof parent.get_vscroll_bar === "function") {
                    scrollView = parent;
                    break;
                }
                parent = parent.get_parent();
            }
            if (scrollView?.vscroll?.adjustment) {
                const adj = scrollView.vscroll.adjustment;
                const [, itemY] = this.get_transformed_position();
                const [, svY] = scrollView.get_transformed_position();
                const relY = itemY - svY;
                const itemH = this.height;
                const visibleH = scrollView.height;
                let targetValue = adj.value;
                let needsScroll = false;
                if (relY < 0) {
                    targetValue += relY;
                    needsScroll = true;
                }
                else if (relY + itemH > visibleH) {
                    targetValue += relY + itemH - visibleH;
                    needsScroll = true;
                }
                if (needsScroll) {
                    // Lock focus to prevent phantom hovers from stealing it during layout shift
                    acquirePhantomHoverLock(this, 50);
                    adj.value = targetValue;
                }
            }
            return GLib.SOURCE_REMOVE;
        });
    }
    // ─── DND Delegate Methods ─────────────────────────────────────────────────
    // GNOME DND calls these on the _delegate, which is set to `this`.
    onDragBegin() {
        this.add_style_class_name("todo-item-modifier-held");
        // Lock the natural allocation so DND layout passes can't inflate this row
        const [, , natW, natH] = this.get_preferred_size();
        this.set_width(natW);
        this.set_height(natH);
    }
    onDragEnd() {
        // Release fixed size so the row can reflow normally after rebuild
        this.set_width(-1);
        this.set_height(-1);
        this._cleanupDragState();
    }
    onDragCancelled() {
        this.set_width(-1);
        this.set_height(-1);
        this._cleanupDragState();
    }
    _cleanupDragState() {
        try {
            this.remove_style_class_name("todo-item-modifier-held");
        }
        catch (_) { }
        try {
            this.remove_style_class_name("todo-drop-target");
        }
        catch (_) { }
        try {
            const parent = this.get_parent();
            if (parent) {
                parent.get_children().forEach(child => {
                    try {
                        if (typeof child.remove_style_class_name === "function") {
                            child.remove_style_class_name("todo-drop-target");
                        }
                    }
                    catch (_) { }
                });
            }
        }
        catch (_) { }
    }
    getDragActor() {
        // DND actors are injected into the global UI group, meaning they lose 
        // inherited CSS classes from the menu/drawer. We must explicitly re-apply them.
        const desktopSettings = new Gio.Settings({ schema_id: "org.gnome.desktop.interface" });
        const isDark = desktopSettings.get_string("color-scheme") === "prefer-dark";
        const themeClass = isDark ? "todo-dark-theme" : "todo-light-theme";
        const box = new St.BoxLayout({
            // Append the evaluated theme class directly to the clone
            style_class: `todo-item-box todo-drag-actor ${themeClass}`,
        });
        // Retain the drag handle icon for visual consistency
        box.add_child(new St.Icon({
            icon_name: "list-drag-handle-symbolic",
            style_class: "todo-drag-icon",
        }));
        // Clone the label state (including crossed-out completed styling)
        box.add_child(new St.Label({
            text: this._text,
            style_class: this._label.style_class,
            y_align: Clutter.ActorAlign.CENTER,
        }));
        return box;
    }
    getDragActorSource() {
        return this;
    }
    // todoItem.ts
    handleDragOver(source, _actor, _x, _y, _time) {
        // Early rejections — always wipe our own highlight first
        if (!source || typeof source.getText !== "function" || source === this) {
            this.remove_style_class_name("todo-drop-target");
            return DND.DragMotionResult?.NO_DROP ?? 0;
        }
        // 1. Clean up sibling highlights
        try {
            const parent = this.get_parent();
            if (parent) {
                parent.get_children().forEach(child => {
                    if (child !== this) {
                        try {
                            child.remove_style_class_name("todo-drop-target");
                        }
                        catch (_) { }
                    }
                });
            }
        }
        catch (_) { }
        // 2. STRICT BOUNDARY ENFORCEMENT
        if (typeof source.getIsPinned === "function" &&
            (source.getIsPinned() !== this.getIsPinned() || source.getIsCompleted() !== this.getIsCompleted())) {
            // CRITICAL FIX: remove highlight before rejecting, otherwise it sticks
            this.remove_style_class_name("todo-drop-target");
            return DND.DragMotionResult?.NO_DROP ?? 0;
        }
        // 3. Valid target — apply highlight
        this.add_style_class_name("todo-drop-target");
        return DND.DragMotionResult?.MOVE_DROP ?? 2;
    }
    // Called automatically by Shell DND when the dragged cursor leaves this actor
    handleDragOut() {
        try {
            this.remove_style_class_name("todo-drop-target");
        }
        catch (_) { }
    }
    acceptDrop(source, _actor, _x, _y, _time) {
        this._cleanupDragState();
        if (!source || typeof source.getText !== "function" || source === this) {
            return false;
        }
        // STRICT BOUNDARY ENFORCEMENT: Prevent array mutation
        if (typeof source.getIsPinned === "function" &&
            (source.getIsPinned() !== this.getIsPinned() || source.getIsCompleted() !== this.getIsCompleted())) {
            return false;
        }
        this.emit("todo-move", source.getText(), this._text);
        return true;
    }
    // ─── Public Accessors ────────────────────────────────────────────────────
    getText() { return this._text; }
    getIsPinned() { return this._isPinned; }
    getIsCompleted() { return this._isCompleted; }
});
