/**
 * core/logger.ts — Colorized Logger
 *
 * Responsibility:
 *   - Provide consistent, grep-friendly logging with ANSI colors
 *   - Format stack traces so `journalctl | grep SnapTodo` catches every line
 *
 * Does NOT:
 *   - Access any GNOME APIs
 *   - Hold any state
 */
// ─── ANSI Color Constants ────────────────────────────────────────────────────
const CYAN = '\x1b[36m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const RESET = '\x1b[0m';
const TAG = `${CYAN}[SnapTodo]${RESET}`;
const ETAG = `${RED}[SnapTodo ERROR]${RESET}`;
// ─── Public API ──────────────────────────────────────────────────────────────
export const Logger = {
    /**
     * Log an informational message.
     * Visible in: journalctl -f -o cat /usr/bin/gnome-shell | grep SnapTodo
     */
    info(msg) {
        print(`${TAG} ${msg}`);
    },
    /**
     * Log an error with a full stack trace.
     * Every line is prefixed with [SnapTodo] so grep keeps it.
     */
    error(context, error) {
        let output = `${ETAG} ${context}`;
        if (error) {
            const err = error;
            const lines = err.stack
                ? err.stack.split('\n').filter(l => l.trim() !== '')
                : [`${err.message ?? error}`];
            for (const line of lines) {
                output += `\n${YELLOW}[SnapTodo]  ↳ ${line.trim()}${RESET}`;
            }
        }
        printerr(output);
    },
};
